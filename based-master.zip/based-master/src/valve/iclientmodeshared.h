#pragma once
#include "cusercmd.h"

class IClientModeShared
{
public:

};
